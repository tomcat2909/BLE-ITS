/* ========================================
 *
 * Copyright The Vagabond Network, 2017
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

void StackEventHandler(uint32 eventcode, void *eventparam)
{
    switch(eventcode)
    {
        case CYBLE_EVT_STACK_ON:    CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_CUSTOM);
                                    led_Write(0x01);
                                    break;
        
    }
 }                           
        

int main(void)
{
    CyGlobalIntEnable;
    
    CyBle_Start(StackEventHandler);
    
    while(1)
    {
        CyBle_ProcessEvents();
    }
    
}
