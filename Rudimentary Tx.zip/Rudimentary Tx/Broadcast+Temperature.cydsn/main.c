/* ========================================
 *
 * Copyright The Vagabond Network, 2017 
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

CYBLE_CONN_HANDLE_T connectionhandle;
static int indication=1;



void StackEventHandler(uint32 eventcode, void *eventparam)
{
    switch(eventcode)
    {
        case CYBLE_EVT_STACK_ON:                    CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
                                                    break;
        
        case CYBLE_EVT_GATT_CONNECT_IND:            connectionhandle=*(CYBLE_CONN_HANDLE_T *)eventparam;
                                                    break;
    }
}

void TemperatureServiceCallback(uint32 eventcode, void *eventparam)
{
    switch(eventcode)
    {
        case CYBLE_EVT_HTSS_INDICATION_ENABLED:     indication=1;
                                                    break;
        
        case CYBLE_EVT_HTSS_INDICATION_DISABLED:    indication=1;
                                                    break;
    }
}   

void SendValue(uint32 valuereceived)
{
    uint8 valuearray[6u];
    
    //if(indication==1)
    {
        //if(CyBle_HtssGetCharacteristicValue(CYBLE_HTS_TEMP_MEASURE,6u,valuearray)==CYBLE_ERROR_OK)
        {
            valuearray[1] = LO8(LO16(valuereceived));
            valuearray[2] = HI8(LO16(valuereceived));
            valuearray[3] = LO8(HI16(valuereceived));
            valuearray[4] = HI8(HI16(valuereceived));
            
            CyBle_HtssSendIndication(connectionhandle,CYBLE_HTS_TEMP_MEASURE,6u,valuearray);
        }
    }
}
            
    
   
int main(void)
{
    uint32 i=10;
    CyGlobalIntEnable;
    
    CyBle_Start(StackEventHandler);
    
    CyBle_HtsRegisterAttrCallback(TemperatureServiceCallback);
    
    while(1)
    {
        CyBle_ProcessEvents();
        
        for(i=0;i<=100;i+=10)
        {
            SendValue(i);
            CyDelay(1000);
        }
    }
    
 
}